package com.aoslec.haezzo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class HaezulgaeListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_haezulgae_list);
    }
}
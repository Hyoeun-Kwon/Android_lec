package com.aoslec.haezzo;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


import com.aoslec.haezzo.Adapter.MyHaezzoListIngAdapter;
import com.aoslec.haezzo.Bean.MyHaezzoListBean;
import com.aoslec.haezzo.LoginActivity.KakaoLoginActivity;
import com.aoslec.haezzo.NetworkTask.MyHaezzoListNetworkTask;

import java.util.ArrayList;



public class FragmentTabIng extends Fragment {

    private View view;

    String macIP = KakaoLoginActivity.macIP;
    String urlAddr = "http://"+macIP+":8080/test/Haezzo/myhaezzoSelectList.jsp?";

    ArrayList<MyHaezzoListBean> myHaezzoListBeans;
    MyHaezzoListIngAdapter myHaezzoListIngAdapter;

    RecyclerView recyclerView = null;
    RecyclerView.LayoutManager layoutManager = null;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Log.v("Message", "FragmentTabIng Start");
        // Inflate the layout for this fragment
        // 첫번째 프레그먼트 연결작업
        view =  inflater.inflate(R.layout.fragment_ing_tab, container, false);
        recyclerView = view.findViewById(R.id.myhaezzo_rvLists);
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);

        //method
        connectGetData();

        return view;
    }

    private void connectGetData(){
        Log.v("Message", "METHOD : fragment1_connectGetData Start");

        try{
            Log.v("Message", " fragment1 - Before start NetworkTask");

            MyHaezzoListNetworkTask networkTask = new MyHaezzoListNetworkTask(getActivity(), urlAddr, "select");
            Object obj = networkTask.execute().get();
            myHaezzoListBeans = (ArrayList<MyHaezzoListBean>) obj;
            Log.v("Message", " fragment - myhaezzo(arraylist) : " + myHaezzoListBeans);

            myHaezzoListIngAdapter = new MyHaezzoListIngAdapter(getActivity(), R.layout.myhaezzolist_custom_layout, myHaezzoListBeans);
            //myHaezzoListWatingAdapter.setOnItemClickListener(adapterClick);
            Log.v("Message", " fragment - adapter is... : " + myHaezzoListIngAdapter);
            recyclerView.setAdapter(myHaezzoListIngAdapter);

        }catch(Exception e){
            e.printStackTrace();
        }

    }//connectGetData


    // test

//    MyHaezzoListWatingAdapter.OnItemClickListener adapterClick = new MyHaezzoListWatingAdapter.OnItemClickListener() {
//        @Override
//        public void onItemClick(View v, int position) {
//            Intent intent = new Intent(getActivity(), NewQuestionActivity.class);
//            String info = workbooks.get(position).getWtitle();
//            int quantity = workbooks.get(position).getQuantity();
//            ShareVar.NewWorkbook_Name = info;
//            ShareVar.totalCount = Integer.toString(quantity);
//            Log.v("Message", "RecyclerView Data : " + info);
//            startActivity(intent);
//        }
//    };


}
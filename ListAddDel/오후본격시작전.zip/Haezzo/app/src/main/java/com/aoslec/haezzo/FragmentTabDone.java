package com.aoslec.haezzo;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.aoslec.haezzo.Adapter.MyHaezzoListDoneAdapter;
import com.aoslec.haezzo.Adapter.MyHaezzoListIngAdapter;
import com.aoslec.haezzo.Bean.MyHaezzoListBean;
import com.aoslec.haezzo.LoginActivity.KakaoLoginActivity;
import com.aoslec.haezzo.NetworkTask.MyHaezzoListNetworkTask;

import java.util.ArrayList;


public class FragmentTabDone extends Fragment {

//    public FragmentTabDone(){
//        Log.v("Message", "Tab2Fragment");
//    }

    private View view;

    String macIP = KakaoLoginActivity.macIP;
    String urlAddr = "http://"+macIP+":8080/test/Haezzo/myhaezzoSelectList.jsp?";

    ArrayList<MyHaezzoListBean> myHaezzoListBeans;
    MyHaezzoListDoneAdapter myHaezzoListDoneAdapter;

    RecyclerView recyclerView = null;
    RecyclerView.LayoutManager layoutManager = null;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Log.v("Message", "FragmentTabDone Start");
        // Inflate the layout for this fragment
        // 첫번째 프레그먼트 연결작업
        view =  inflater.inflate(R.layout.fragment_done_tab, container, false);
        recyclerView = view.findViewById(R.id.myhaezzoListDone_rvLists);
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);

        //method
        connectGetData();

        return view;
    }

    private void connectGetData(){
        Log.v("Message", "METHOD : fragment1_connectGetData Start");

        try{
            Log.v("Message", " fragment2 - Before start NetworkTask");

            MyHaezzoListNetworkTask networkTask = new MyHaezzoListNetworkTask(getActivity(), urlAddr, "select");
            Object obj = networkTask.execute().get();
            myHaezzoListBeans = (ArrayList<MyHaezzoListBean>) obj;
            Log.v("Message", " fragment2 - myhaezzo(arraylist) : " + myHaezzoListBeans);

            myHaezzoListDoneAdapter = new MyHaezzoListDoneAdapter(getActivity(), R.layout.myhaezzolist_custom_done_layout, myHaezzoListBeans);
            //myHaezzoListWatingAdapter.setOnItemClickListener(adapterClick);
            Log.v("Message", " fragment2 - adapter is... : " + myHaezzoListDoneAdapter);
            recyclerView.setAdapter(myHaezzoListDoneAdapter);

        }catch(Exception e){
            e.printStackTrace();
        }

    }//connectGetData



}//--------
package com.aoslec.haezzo.Bean;

public class HelperBean {

    private String hnumber;
    private String haccountimage;
    private String hname;
    private String hbank;
    private String haccount;
    private String hidcardimage;
    private String hprofileimage;
    private String hself;
    private String hgaga;
    private String hrating;

    public HelperBean(String hnumber, String haccountimage, String hname, String hbank, String haccount, String hidcardimage, String hprofileimage, String hself, String hgaga, String hrating) {
        this.hnumber = hnumber;
        this.haccountimage = haccountimage;
        this.hname = hname;
        this.hbank = hbank;
        this.haccount = haccount;
        this.hidcardimage = hidcardimage;
        this.hprofileimage = hprofileimage;
        this.hself = hself;
        this.hgaga = hgaga;
        this.hrating = hrating;
    }

    public String getHnumber() {
        return hnumber;
    }

    public void setHnumber(String hnumber) {
        this.hnumber = hnumber;
    }

    public String getHaccountimage() {
        return haccountimage;
    }

    public void setHaccountimage(String haccountimage) {
        this.haccountimage = haccountimage;
    }

    public String getHname() {
        return hname;
    }

    public void setHname(String hname) {
        this.hname = hname;
    }

    public String getHbank() {
        return hbank;
    }

    public void setHbank(String hbank) {
        this.hbank = hbank;
    }

    public String getHaccount() {
        return haccount;
    }

    public void setHaccount(String haccount) {
        this.haccount = haccount;
    }

    public String getHidcardimage() {
        return hidcardimage;
    }

    public void setHidcardimage(String hidcardimage) {
        this.hidcardimage = hidcardimage;
    }

    public String getHprofileimage() {
        return hprofileimage;
    }

    public void setHprofileimage(String hprofileimage) {
        this.hprofileimage = hprofileimage;
    }

    public String getHself() {
        return hself;
    }

    public void setHself(String hself) {
        this.hself = hself;
    }

    public String getHgaga() {
        return hgaga;
    }

    public void setHgaga(String hgaga) {
        this.hgaga = hgaga;
    }

    public String getHrating() {
        return hrating;
    }

    public void setHrating(String hrating) {
        this.hrating = hrating;
    }
}
